// https://developers.google.com/custom-search/v1/introduction#identify_your_application_to_google_with_api_key
// https://developers.google.com/custom-search/v1/using_rest
// https://cse.google.com/cse/create/new
// d55f8779092ce639b
export const API_KEY = "AIzaSyAXOIMkbVuc1wlEkXZB5xICh-a7SiZaXa0";

export default API_KEY;
